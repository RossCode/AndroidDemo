package com.Develomatic.AndroidDemo.Core;

public class User {
	private String name;
	public void setName(String value) {
		name = value;
	}
	public String getName() {
		return name;
	}
}
