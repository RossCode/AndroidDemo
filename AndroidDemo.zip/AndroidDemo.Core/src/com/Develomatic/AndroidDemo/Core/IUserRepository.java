package com.Develomatic.AndroidDemo.Core;

public interface IUserRepository {
	User get();
}
