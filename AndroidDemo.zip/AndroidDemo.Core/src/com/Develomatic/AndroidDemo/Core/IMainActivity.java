package com.Develomatic.AndroidDemo.Core;

public interface IMainActivity {
	void setUserNameTo(String name);
}